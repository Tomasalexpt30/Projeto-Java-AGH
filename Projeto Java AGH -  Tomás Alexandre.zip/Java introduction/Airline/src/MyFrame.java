
public class MyFrame {
	
	
	public static void main(String[] args) {
		Client client = new Client();
		Seat seat = new Seat();
            new FlightFrame(client, seat);
	}

}
