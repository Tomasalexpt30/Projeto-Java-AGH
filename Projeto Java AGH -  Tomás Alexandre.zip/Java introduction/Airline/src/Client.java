import javax.swing.JOptionPane;

public class Client {
	
	String name;
	String surname;
	String id;
	double payment;

	public void setName(String name) {
		this.name = name;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public void setID(String id) {
		this.id = id;
	}
	public String getName() {
        return this.name;
    }
    public String getsurName() {
        return this.surname;
    }
    public String getid() {
        return this.id;
    }
	void pay(double seatprice,int baggage,  int plus, double payment) {
		this.payment = seatprice + baggage + plus;
	}
	void pay(double seatprice,int baggage, double payment) {
		this.payment = seatprice + baggage ;
		
	}
	void pay(double seatprice, double payment) {
		this.payment = seatprice;
	}
	public void setPayment(double pay) {
		this.payment=pay;
	}
	public double getPayment() {
		return this.payment;
	}
	
	
}
