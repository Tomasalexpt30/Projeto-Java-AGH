import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Bilhete extends JFrame {
	Client client;
	Seat seat;
	
	public Bilhete(Client client, Seat seat){
		setTitle("Your Ticket");
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setSize(400, 400);
        setResizable(false);
        setLayout(null);
        setVisible(true);
        
        JPanel identificacao = new JPanel();
        identificacao.setBounds(0,0,400,400);
        identificacao.setBackground(Color.black);
        identificacao.setLayout(null);
        
        JLabel nameLabel = new JLabel("Name: " + client.getName());
        nameLabel.setFont(new Font("Herald",Font.BOLD,12));
        nameLabel.setForeground(Color.white);
        nameLabel.setBounds(10,10,200,20);
        JLabel surnameLabel = new JLabel("Surname: " + client.getsurName());
        surnameLabel.setFont(new Font("Herald",Font.BOLD,12));
        surnameLabel.setForeground(Color.white);
        surnameLabel.setBounds(10,50,200,20);
        JLabel idLabel = new JLabel("ID: " + client.getid());
        idLabel.setFont(new Font("Herald",Font.BOLD,12));
        idLabel.setForeground(Color.white);
        idLabel.setBounds(10,90,200,20);
        JLabel priceLabel = new JLabel("Your ticket Price: " +client.getPayment());
        priceLabel.setFont(new Font("Herald",Font.BOLD,12));
        priceLabel.setForeground(Color.white);
        priceLabel.setBounds(10,130,200,20);
        JLabel seatLabel = new JLabel("Your Seat: " +seat.getSeatLabel());
        seatLabel.setFont(new Font("Herald",Font.BOLD,12));
        seatLabel.setForeground(Color.white);
        seatLabel.setBounds(10,170,200,20);
        JLabel typeofPayLabel = new JLabel("Your method of Payment: " +seat.getTypeOfPayment());
        typeofPayLabel.setFont(new Font("Herald",Font.BOLD,12));
        typeofPayLabel.setForeground(Color.white);
        typeofPayLabel.setBounds(210,130,200,20);
        
        identificacao.add(typeofPayLabel);
        identificacao.add(nameLabel);
        identificacao.add(surnameLabel);
        identificacao.add(idLabel);
        identificacao.add(priceLabel);
        identificacao.add(seatLabel);

        setLocationRelativeTo(null);
        add(identificacao);
	
	}
}
