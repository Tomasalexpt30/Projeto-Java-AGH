
public class Seat {
	 private boolean isSelected = false;
	 String seatLabel;
	 String type;
	 public void setseat(String seatLabel) {
	        this.seatLabel = seatLabel;
	    }

	    public void toggleSelection() {
	        isSelected = !isSelected;
	    }

	    public boolean isSelected() {
	        return isSelected;
	    }

	    public String getSeatLabel() {
	        return this.seatLabel;
	    }
	    public void setTypeOfPay(String typeOfPayment) {
	    	this.type= typeOfPayment;
	    }
	    public String getTypeOfPayment() {
	    	return this.type;
	    }
}
