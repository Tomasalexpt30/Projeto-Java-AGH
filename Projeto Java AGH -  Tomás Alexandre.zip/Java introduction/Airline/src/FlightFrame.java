import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;

public class FlightFrame extends JFrame {
	
	private static final int ROWS = 30;
    private static final int COLUMNS = 6;
    public static final double seatPrice = 159.99;
    public static final int holdLuggage = 20;
    public static final int handLuggage = 0;
    public static final int insurancePrice = 25;
    double totalPay = 0.00;
    static final int idFlight = 12345;
    String selectedSeatLabel;
    Client client;
    Seat seat;
    Client pay;
	
	 public FlightFrame(Client client, Seat seat){
		 this.client = client;
		 this.seat= seat;
		 	setTitle("UAirLines");
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setSize(1100, 700);
	        setBackground(Color.white);
	        setResizable(false);
	        ImageIcon image = new ImageIcon("UAL.png");
	        setIconImage(image.getImage());
	        setLayout(null);
		  
	        JPanel plane = new JPanel();
	        plane.setBounds(0, 0, 400, 700);
	        plane.setBackground(Color.blue);
	        
	        JPanel flightPanel = new JPanel(new GridLayout(ROWS, COLUMNS, 5, 5));
	        flightPanel.setBackground(Color.blue);
	        flightPanel.setBounds(0,0,400,700);
	        flightPanel.setPreferredSize(new java.awt.Dimension(390 , 660));
	        plane.add(flightPanel);
	        add(plane);
	        

	        // Cria os botões para os assentos
	        for (int row = 1; row <= ROWS; row++) {
	            for (int col = 0; col < COLUMNS; col++) {//começa em 0 para ter as colunas a começar em A e não em B
	                String seatLabel = String.format("%c%d", 'A' + col, row);
	                
	                JButton seatButton = new JButton(seatLabel);
	                seatButton.setBackground(Color.white);
	                seatButton.setSize(5,5);
	                seatButton.setFocusable(false);
	                
	                seatButton.addActionListener(e -> {
	                    seat.toggleSelection();
	                    seat.setseat(seatLabel);
	                    seatButton.setBackground(seat.isSelected() ? Color.green : Color.white);
	                    });
	                flightPanel.add(seatButton);}
	        }
            
	        JPanel inform= new JPanel();
	        inform.setBounds(550,0,500,450);
	        inform.setLayout(null);
	        
	        JLabel text = new JLabel("On your left you have the seats ready to pick on flight "+ idFlight+".");
	        text.setBounds(0,0,380,40);
	        text.setFont(new Font("Herald",Font.BOLD,12));
	        
	        JLabel text1 = new JLabel("Be aware the seats on Columns A and F are next to windows!");
	        text1.setBounds(0,25,350,40);
	        text1.setFont(new Font("Herald",Font.BOLD,12));
	        
	        inform.add(text1);
	        inform.add(text);
	        
	        JLabel nameLabel = new JLabel("Please put your name:");
	        nameLabel.setBounds(100,50,250,20);
	        inform.add(nameLabel);
	        
	        JTextField nameTextField = new JTextField();
	        nameTextField.setBounds(40,70,250,20);
	        inform.add(nameTextField);

	        JLabel surnameLabel = new JLabel("Please put your surname:");
	        surnameLabel.setBounds(100,100,250,20);
	        inform.add(surnameLabel);
	        
	        JTextField surnameTextField = new JTextField();
	        surnameTextField.setBounds(40, 120, 250, 20);
	        inform.add(surnameTextField);
	 
	        JLabel idLabel = new JLabel("Please put your ID:");
	        idLabel.setBounds(100, 155, 250, 20);
	        inform.add(idLabel);
	        
	        JTextField idTextField = new JTextField();
	        idTextField.setBounds(40, 175, 250, 20);
	        inform.add(idTextField);
	        
	        JCheckBox luggage = new JCheckBox();
	        luggage.setText("Hold luggage");
	        luggage.setFocusable(false);
	        luggage.setBounds(190,240,230,40);
	        inform.add(luggage);
	        
	        JCheckBox baggage = new JCheckBox();
	        baggage.setText("Hand Baggage");
	        baggage.setFocusable(false);
	        baggage.setBounds(40,240,130,40);
	        baggage.setSelected(true);
	        inform.add(baggage);
	      
	        String[] typeOfPayment = {"","VISA","MASTERCARD","PAYPAL"};
	        JComboBox payment = new JComboBox(typeOfPayment);
	        payment.setBounds(60,330,210,20);
	        
	        JCheckBox insurance = new JCheckBox();
	        insurance.setText("Would you like Insurance?");
	        insurance.setFocusable(false);
	        insurance.setBounds(90,210,230,40);
	        inform.add(insurance);
	        inform.add(payment);
	        
	        JLabel fullPrice = new JLabel();
	        fullPrice.setBounds(90,460,200,30);
	        fullPrice.setText("Your ticket price is: ");
	        
	        JButton priceButton = new JButton("Access ticket price");
	        priceButton.setBounds(90, 420, 160, 20);
	        priceButton.setFocusable(false);
	        priceButton.setEnabled(false);
	        priceButton.addActionListener(e-> {
	        	if(luggage.isSelected() && insurance.isSelected()) {
	        		client.pay(seatPrice, holdLuggage, insurancePrice,totalPay);
	        		new Bilhete(client, seat);
	        	}else if(insurance.isSelected()){
	        		client.pay(seatPrice,insurancePrice,totalPay);
	        		new Bilhete(client, seat);
	        	}else if(luggage.isSelected()) {
	        		client.pay(seatPrice,holdLuggage,totalPay);
	        		new Bilhete(client, seat);
	        	}else {
	        		client.pay(seatPrice,totalPay);
	        		new Bilhete(client, seat);
	        	}
	        });
	        inform.add(priceButton);
	        
	        JButton addButton = new JButton("Submit");
	        addButton.setBounds(130, 370, 80, 20);
	        addButton.setFocusable(false);
	        addButton.addActionListener(e ->{
	        	String nameText =nameTextField.getText();
	        	String surnameText =surnameTextField.getText();
	        	String idText =idTextField.getText();
	        	if (nameText == null || nameText.trim().isEmpty() ||
	                    surnameText == null || surnameText.trim().isEmpty() ||
	                    idText == null || idText.trim().isEmpty()) {
	                    JOptionPane.showMessageDialog(null, "Fields not valid","You must put in your data",JOptionPane.OK_OPTION);
	                }else if (idText.length() != 8) {
	                	JOptionPane.showMessageDialog(null, "ID not valid","ID must be 8 numbers",JOptionPane.OK_OPTION);
	                }  else {
	                	client.setName(nameText);
	                	client.setSurname(surnameText);
	                	client.setID(idText);
	                	priceButton.setEnabled(true);
	                	seat.setTypeOfPay(typeOfPayment[1]);
	                }
	        } );
	        inform.add(addButton);
	        add(inform);
	        setVisible(true);
	 }
}
